package net.javaguides.springboot.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor


//If client wants the custom response like below
//        {
//        "timeStamp": "2024-10-26T19:19:46.590319",
//        "message": "User not found with id : '99'",
//        "path": "uri=/api/users/99",
//        "errorCode": "USER_NOT_FOUND"
//        }
public class ErrorDetails {
    private LocalDateTime timeStamp;
    private String message;
    private String path;
    private String errorCode;
}
