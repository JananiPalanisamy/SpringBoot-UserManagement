package net.javaguides.springboot.dto;


import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(
        description = "UserDTO Model Information"
)
public class UserDTO {

    private Long id;

    //User first name should not be null or empty
    @NotEmpty(message = "User first name should not be empty")
    @Schema(description = "User First Name")
    private String firstName;

    //User last name should not be null or empty
    @NotEmpty(message = "User last name should not be empty")
    @Schema(description = "User Last Name")
    private String lastName;

    //User email should not be null or empty
    //User email should be valid
    @NotEmpty(message = "User email should not be empty")
    @Email(message = "Email should be valid")
    @Schema(description = "User Email Address")
    private String email;

}
