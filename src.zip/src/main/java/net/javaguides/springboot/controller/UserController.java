package net.javaguides.springboot.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import net.javaguides.springboot.dto.UserDTO;
import net.javaguides.springboot.entity.User;
import net.javaguides.springboot.exception.ErrorDetails;
import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.mapper.UserMapper;
import net.javaguides.springboot.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@RestController
@RequestMapping("api/users")
@Tag(
        name = "CRUD REST APIs for User Resource",
        description = "Create User, Update User, Get User, Get All User, Delete User"
)
public class UserController {

    private UserService userService;
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Operation(
            summary = "Create user",
            description = "Create user with firstname, lastname, email will saved be db"
    )
    @ApiResponse(
            responseCode = "201",
            description = "Http Status 201 Created"
    )
    @PostMapping("create")
    public ResponseEntity<UserDTO> createUser(@RequestBody @Valid UserDTO userDTO){
        UserDTO savedDTOUser = userService.createUser(userDTO);
        return  new ResponseEntity<>(savedDTOUser, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Get user",
            description = "Get User by giving a id"
    )
    @ApiResponse(
            responseCode = "200",
            description = "Http Status 200 Success"
    )
    @GetMapping("/{id}")
    public ResponseEntity<UserDTO> getUserById(@PathVariable("id") Long id){
        UserDTO userDTO = userService.getUserById(id);
        return ResponseEntity.ok(userDTO);
    }

    @Operation(
            summary = "Get All Users",
            description = "Get all users from db"
    )
    @ApiResponse(
            responseCode = "200",
            description = "Http Status 200 Success"
    )
    @GetMapping
    public ResponseEntity<List<UserDTO>> getAllUser(){
        List<UserDTO> usersDTO = userService.getAllUsers();
        return ResponseEntity.ok(usersDTO);
    }

    @Operation(
            summary = "Update user",
            description = "Update user with firstname, lastname or email will updated be db"
    )
    @ApiResponse(
            responseCode = "201",
            description = "Http Status 201 Created"
    )
    @PutMapping("/{id}")
    // http://localhost:8080/api/users/1
    public ResponseEntity<UserDTO> updateUserDetails(@PathVariable("id") Long userId, @RequestBody @Valid UserDTO userDTO){
        userDTO.setId(userId);
        UserDTO updatedUser = userService.updateUser(userDTO);
        System.out.println("==> Updated first name: "+updatedUser.getFirstName());
        System.out.println("==> Updated last name:  "+updatedUser.getLastName());
        System.out.println("==> Updated email:      "+updatedUser.getEmail());
        return ResponseEntity.ok(updatedUser);
    }


    @Operation(
            summary = "Delete user",
            description = "Delete user by giving id"
    )
    @ApiResponse(
            responseCode = "200",
            description = "Http Status 200 Success"
    )
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteUserById(@PathVariable("id") Long id){
        userService.deleteUser(id);
        return ResponseEntity.ok("User deleted successfully!");
    }

//    @ExceptionHandler(ResourceNotFoundException.class)//annotation handles specific exception and sends custom response to client
//    public ResponseEntity<ErrorDetails> handleResourceNotFoundException(ResourceNotFoundException exception,
//                                                                        WebRequest webRequest) {
//        ErrorDetails errorDetails = new ErrorDetails(
//                LocalDateTime.now(),
//                exception.getMessage(),
//                webRequest.getDescription(false), //get client info is set to false
//                "USER_NOT_FOUND"
//        );
//        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
//    }

    @GetMapping("/welcome")
    public String welcome(){
        logger.info("starting my greeting method.....");
        return "Greeting! Welcome to user management service";
    }

}
