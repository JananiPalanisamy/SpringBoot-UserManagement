package net.javaguides.springboot.service.impl;

import lombok.AllArgsConstructor;
import net.javaguides.springboot.dto.UserDTO;
import net.javaguides.springboot.entity.User;
import net.javaguides.springboot.exception.EmailAlreadyExistsException;
import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.mapper.AutoUserMapper;
import net.javaguides.springboot.mapper.UserMapper;
import net.javaguides.springboot.repository.UserRepository;
import net.javaguides.springboot.service.UserService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;
    private ModelMapper modelMapper;
    private static final Logger logger = LogManager.getLogger(UserServiceImpl.class);



    @Override
    public UserDTO createUser(UserDTO userDTO) {

        //convert DTO to JPA Entity
//        User user = UserMapper.mapToUser(userDTO);
//        User user = modelMapper.map(userDTO, User.class);

        //email already exists exception
        Optional<User> optionalUser = userRepository.findByEmail(userDTO.getEmail());

        if(optionalUser.isPresent())
        {
            logger.error("Email exists already");
            throw new EmailAlreadyExistsException("Email Already Exixsts");
        }
        User user = AutoUserMapper.MAPPER.mapToUser(userDTO);

        User savedUser = userRepository.save(user);

        //convert JPA entity to DTO
//        UserDTO userDTO1 = UserMapper.mapToUserDTO(savedUser);
//        UserDTO userDTO1 = modelMapper.map(savedUser, UserDTO.class);
        UserDTO userDTO1 = AutoUserMapper.MAPPER.mapToUserDto(savedUser);

        return userDTO1;
    }

    @Override
    public UserDTO getUserById(Long id) {
        logger.info("Get user by id");
        User user = userRepository.findById(id).orElseThrow(
                () -> new ResourceNotFoundException("User", "id", id)
        );
//        User user = optionalUser.get(); //removing after adding exception
//        return UserMapper.mapToUserDTO(user);
//        return modelMapper.map(user, UserDTO.class);
        return AutoUserMapper.MAPPER.mapToUserDto(user);
    }

    @Override
    public List<UserDTO> getAllUsers() {
        logger.info("Get all users2");
        List<User> users = userRepository.findAll();
//        return users.stream().map(UserMapper::mapToUserDTO)
//                .collect(Collectors.toList());
//        return users.stream().map((user) -> modelMapper.map(user, UserDTO.class))
//                .collect(Collectors.toList());
        return users.stream().map((user) -> AutoUserMapper.MAPPER.mapToUserDto(user))
                .collect(Collectors.toList());
    }

    @Override
    public UserDTO updateUser(UserDTO userDTO) {

        User existingUser = userRepository.findById(userDTO.getId()).orElseThrow(
                () -> new ResourceNotFoundException("User", "id", userDTO.getId()) //lambda expression
        );
        existingUser.setFirstName(userDTO.getFirstName());
        existingUser.setLastName(userDTO.getLastName());
        existingUser.setEmail(userDTO.getEmail());

        User updatedUser = userRepository.save(existingUser);

//        UserDTO updatedUserDTO = UserMapper.mapToUserDTO(updatedUser);
//        UserDTO updatedUserDTO = modelMapper.map(updatedUser, UserDTO.class);
        UserDTO updatedUserDTO = AutoUserMapper.MAPPER.mapToUserDto(updatedUser);



        return updatedUserDTO;
    }

    @Override
    public void deleteUser(Long id) {
        User existingUser = userRepository.findById(id).orElseThrow(
                () -> new ResourceNotFoundException("User", "id", id)
        );
        userRepository.deleteById(existingUser.getId());
    }
}
